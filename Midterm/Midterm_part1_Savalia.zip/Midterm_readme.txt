Plots contain plots for question 1 and 2
Midterm.R is the code for questions 1 and 2 (along with a little code for question 3 and 4 since I'm using the same functions)
The Tables folder contains tables for questions 3 and 4 in folders Q3 and Q4 respectively.
Files "..._param.csv" are the fit parameter tables; exg, gam and wald for Ex-Gaussian, Gamma and Wald distributions respectively
Files "gsq.csv" contains the gsq values for those fit parameters.
Q4 contains 2 folders for the two cases; single_v is for when v doesn't vary and double_v for otherwise.
